/**
 * 
 */
/**
 * 
 */
module GestorTurnosConsulta {
	requires org.junit.jupiter.api;
}