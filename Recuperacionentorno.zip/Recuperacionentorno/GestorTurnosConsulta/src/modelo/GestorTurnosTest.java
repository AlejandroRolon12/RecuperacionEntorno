package modelo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class GestorTurnosTest {

    private GestorTurnos gestor;

    @BeforeEach
    public void setUp() {
        gestor = new GestorTurnos();
    }

    @Test
    public void testAñadirPaciente() {
        gestor.agregarPaciente("Mario", "Dolor de muelas", 2);
        assertEquals("Mario", gestor.verNombreSiguientePaciente());
    }

    @Test
    public void testAtenderPacientePorPrioridad() {
        gestor.agregarPaciente("Pedro", "Consulta", 3);
        gestor.agregarPaciente("Luis", "Urgencia", 1);
        gestor.agregarPaciente("Ana", "Dolor cabeza", 2);

        Paciente atendido = gestor.atenderSiguientePaciente();
        assertNotNull(atendido);
        assertEquals("Luis", atendido.getNombre());
    }

    @Test
    public void testCancelarTurno() {
        gestor.agregarPaciente("Ana", "Dolor cabeza", 2);
        assertTrue(gestor.cancelarTurnoPorNombre("Ana"));
        assertFalse(gestor.cancelarTurnoPorNombre("Ana")); // ya cancelado
    }

    @Test
    public void testContarPacientesPorPrioridad() {
        gestor.agregarPaciente("Ana", "Dolor cabeza", 2);
        gestor.agregarPaciente("Luis", "Urgencia", 1);
        gestor.agregarPaciente("Pedro", "Consulta", 3);
        gestor.agregarPaciente("Marta", "Dolor espalda", 2);

        assertEquals(1, gestor.contarPacientesPorPrioridad(1));
        assertEquals(2, gestor.contarPacientesPorPrioridad(2));
        assertEquals(1, gestor.contarPacientesPorPrioridad(3));
    }
}
