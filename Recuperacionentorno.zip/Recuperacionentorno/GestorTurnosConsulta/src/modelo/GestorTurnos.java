package modelo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class GestorTurnos {
    private List<Paciente> pacientes = new ArrayList<>();

    // Añade un nuevo paciente a la lista de espera
    public void agregarPaciente(String nombre, String motivoConsulta, int prioridad) {
        pacientes.add(new Paciente(nombre, motivoConsulta, prioridad));
    }

    // Devuelve el paciente con la prioridad más alta sin eliminarlo
    public Paciente obtenerSiguientePaciente() {
        Paciente siguiente = null;
        int prioridadMasAlta = Integer.MAX_VALUE;

        for (Paciente p : pacientes) {
            if (p.getPrioridad() < prioridadMasAlta) {
                prioridadMasAlta = p.getPrioridad();
                siguiente = p;
            }
        }
        return siguiente;
    }

    // Devuelve el nombre del siguiente paciente a atender o null si no hay
    public String verNombreSiguientePaciente() {
        Paciente siguiente = obtenerSiguientePaciente();
        return (siguiente != null) ? siguiente.getNombre() : null;
    }

    // Atender (eliminar y devolver) el paciente con prioridad más alta
    public Paciente atenderSiguientePaciente() {
        Paciente siguiente = obtenerSiguientePaciente();
        if (siguiente != null) {
            pacientes.remove(siguiente);
        }
        return siguiente;
    }

    // Cuenta cuántos pacientes hay con una prioridad dada
    public int contarPacientesPorPrioridad(int prioridad) {
        int contador = 0;
        for (Paciente p : pacientes) {
            if (p.getPrioridad() == prioridad) {
                contador++;
            }
        }
        return contador;
    }

    // Cancela turno de paciente por nombre (elimina el primero que coincida)
    public boolean cancelarTurnoPorNombre(String nombre) {
        Iterator<Paciente> it = pacientes.iterator();
        while (it.hasNext()) {
            if (it.next().getNombre().equals(nombre)) {
                it.remove();
                return true;
            }
        }
        return false;
    }
}
