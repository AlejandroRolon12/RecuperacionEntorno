package modelo;

public class Main {
    public static void main(String[] args) {
        GestorTurnos gestor = new GestorTurnos();

        gestor.agregarPaciente("Ana", "Dolor de cabeza", 2);
        gestor.agregarPaciente("Luis", "Urgencia", 1);
        gestor.agregarPaciente("Pedro", "Consulta general", 3);

        System.out.println("Siguiente en ser atendido: " + gestor.verNombreSiguientePaciente());
        Paciente atendido = gestor.atenderSiguientePaciente();
        System.out.println("Paciente atendido: " + atendido.getNombre());
        System.out.println("Pacientes con prioridad 1: " + gestor.contarPacientesPorPrioridad(1));
        System.out.println("Cancelar turno Ana: " + gestor.cancelarTurnoPorNombre("Ana"));
    }
}
