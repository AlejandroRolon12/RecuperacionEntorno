package modelo;

public class Paciente {
    private String nombre;
    private String motivo;
    private int prioridad;

    public Paciente(String nombre, String motivo, int prioridad) {
        this.nombre = nombre;
        this.motivo = motivo;
        this.prioridad = prioridad;
    }

    public String getNombre() {
        return nombre;
    }

    public String getMotivo() {
        return motivo;
    }

    public int getPrioridad() {
        return prioridad;
    }
}
